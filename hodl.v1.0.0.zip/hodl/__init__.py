from electroncash.i18n import _

fullname = 'HODL'
description = _('Lock your funds and have no FUD')
available_for = ['qt']
